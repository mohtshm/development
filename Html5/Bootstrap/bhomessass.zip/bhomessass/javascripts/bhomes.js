﻿
$(document).ready(function () {
  
    
        $('.navbar-collapse ul .navbar_ul_li_lg a').hover(function () {
            if ($(this).find("headerTextHovering") > -1) {
            } else {
                $(this).find(">:first-child").next().toggleClass('headerlinehovering');
            }
            if ($(this).find(">:first-child").next().find("headerlinehovering") > -1) {
            } else {
                $(this).toggleClass('headerTextHovering');
            }
        });
     
        $('.navbar-collapse ul .navbar_ul_li_lg a').click(function () {
            if ($(".headerTextHovering").length > 0) {
                $('.navbar-collapse ul li a div').removeClass('headerlinehovering').addClass('header-lines');
                $('.navbar-collapse ul li a').removeClass('headerTextHovering');
            }
            $(this).find(">:first-child").next().removeClass('header-lines').addClass('headerlinehovering');
            $(this).addClass('headerTextHovering');
        });
     $('.navbar-collapse ul li a').click(function () {
       if ($(".headerTextHovering").length > 0) {          
           $('.navbar-collapse ul li a div').removeClass('headerlinehovering').addClass('header-line');
           $('.navbar-collapse ul li a').removeClass('headerTextHovering');
      }           
       $(this).find(">:first-child").next().removeClass('header-line').addClass('headerlinehovering');
       $(this).addClass('headerTextHovering');
    });
        //$(".navbar_ul_li_xs").on("click", function (e) {
        //    if (($(this).hasClass('open'))) {

        //        var current = $(this).find(">:first-child");

        //        var grandparent = $(this).parent().parent();
        //        if ($(this).hasClass('open') || $(this).find(">:first-child").html() == '(-)')
        //            $(this).toggleClass('right-caret left-caret');
        //        grandparent.find('.left-caret').not(this).toggleClass('right-caret left-caret');
        //        grandparent.find(".sub-menu:visible").not(current).hide();
        //        current.toggle();
        //        e.stopPropagation();
        //    }

        //});
        $('ul.dropdown-menu .dropdown a').on('click', function (event) {
            var hasToggle = typeof $(this).attr('data-toggle') !== "undefined";
            if (hasToggle) {
                event.preventDefault();
                event.stopPropagation();
            }
            $(this).parent().toggleClass('open');
            $(this).toggleClass('open');
        });
        $('.navbarheader').affix({
            offset: {
                top: 100
            }
        });
        $('#top').affix({
            offset: {
                top: 100
            }
        });
        //$('.header-container').affix({
        //    offset: {
        //        top: 100
        //    }
        //});
       

        $('#btns_MenuIcon').click(function () {
            $('.navbarheader').toggleClass('affix');
            //if (!$('.navbarheader').hasclass('affix')) {

            //    $('#top').addclass('top_bottom_boarder');
            //}
            //else {
            //    $('#top').removeclass('top_bottom_boarder');
            //    $('#top').affix({
            //        offset: {
            //            top: 100
            //        }
            //    });
            //}
                
            
           
            
        });
      
   // pink_button click event
    $(window).scroll(function () {
        var scroll = $(window).scrollTop();          
        if (scroll >= 100) {
            $('.header-container').affix({
                offset: {
                    top: 100
                }
            });
        }
        else {
            $(".header-container").removeClass('affix');
            $(".header-container").removeClass('affix-top');
        }
    });      
               
});




 

function change_icons_position() {
    $('.navbarheader').removeClass('affix-top');
        $("div.countryReference").addClass('display_none');
        $("div.signInSignUp").addClass('display_none');
        $("div.menuMobileLine").addClass('display_none');
        $("button.btn").addClass('navbar_toggle_collaspe');
        $(".btn span").addClass('icon_bar_collaspe');
        $("div.btns").addClass('width_lines');
        $("div.headerNavBar").addClass('margin_left');
    }

    function revert_icons_position() {
        $("div.signInSignUp").removeClass('display_none');
        $("div.countryReference").removeClass('display_none');
        $("div.menuMobileLine").removeClass('display_none');
        $("button.btn").removeClass('navbar_toggle_collaspe');
        $(".btn span").removeClass('icon_bar_collaspe');
        $("div.headerNavBar").removeClass('margin_left');
        $("div.btns").removeClass('width_lines');
    }