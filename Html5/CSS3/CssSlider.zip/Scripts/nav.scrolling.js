jQuery.noConflict();
jQuery(document).ready(function() {
   jQuery(window).scroll(function(){
		var currentPosition = jQuery(window).scrollTop();
		if(currentPosition > 150){
		if(!jQuery('nav').hasClass('slideUp'))
		jQuery('nav').addClass('slideUp');
		}
		else 	if(jQuery('nav').hasClass('slideUp')){
		jQuery('nav').removeClass('slideUp');
		}
   });

});
