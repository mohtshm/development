jQuery.noConflict();
jQuery(document).ready(function() {
   jQuery(window).scroll(function(){
		var currentPosition = jQuery(window).scrollTop();
		if(currentPosition > 150){
		if(!jQuery('nav').hasClass('slideUp')){		
			
		jQuery('.brand').addClass('.brandslide');
		jQuery('.brand').addClass('slideUp');
		
		setTimeout(function(){ jQuery('.brand').removeClass('brandslide');
	jQuery('nav').addClass('slideUp');		}, 3000);
		
		   }
		
		}
		else if(jQuery('nav').hasClass('slideUp'))
		{
		jQuery('nav').removeClass('slideUp');
		//jQuery('.brand').removeClass('brandslide');
		//jQuery('.brand').removeClass('slideUp');
		}
   });

});
