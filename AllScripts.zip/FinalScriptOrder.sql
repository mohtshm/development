-- select * from catalog_product_entity_media_gallery
SET GLOBAL FOREIGN_KEY_CHECKS=0;
  -- call `Customer_Migrate`();
 -- CALL Product_Migrate();
 


CALL add_sales_flat_address();
CALL add_sales_quote_payment();
CALL `add_order_items`();
CALL `add_order_grid_shippingrate`();
 
 
 
-- TRUNCATE TABLE core_url_rewrite; 
--  CALL  `add_product_url_rewrite`();
 
-- call add_customer_varchar_looping();

-- select * from tempcustomervarchar where entity_id like  '%52214%'

SET GLOBAL FOREIGN_KEY_CHECKS=1;