using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Text;
using System.Net;
using System.IO;

public partial class samples_MultiWebRequest : System.Web.UI.Page
{
    HttpWebRequest req1;
    HttpWebRequest req2;
    IAsyncResult result1;
    IAsyncResult result2;
    DataSet ds1 = new DataSet();
    DataSet ds2 = new DataSet();   

    protected void Page_Load(object sender, EventArgs e)
    {   
        // Register the two separate WebRequests as AsyncTasks, 
        // specifying that they should be run in parallel:
        Page.RegisterAsyncTask( new PageAsyncTask(new BeginEventHandler(this.BeginAsyncWork1),
                                 new EndEventHandler(this.EndAsyncWork1), new EndEventHandler(this.TimeoutHandler), true) );
        Page.RegisterAsyncTask(new PageAsyncTask(new BeginEventHandler(this.BeginAsyncWork2),
                                 new EndEventHandler(this.EndAsyncWork2), new EndEventHandler(this.TimeoutHandler), true));


    }

    protected override void OnPreRenderComplete(EventArgs e)
    {
       base.OnPreRenderComplete(e);
        // write the result messages to the Label.
        MessageOut();
    }

    IAsyncResult BeginAsyncWork1(Object sender, EventArgs e, AsyncCallback cb, object state)
    {
        AddTraceMessage("BeginAsyncWork"); 
       AddTraceMessage("BeginGetRSSOne");
       this.req1 = (HttpWebRequest)WebRequest.Create("http://www.eggheadcafe.com/forumrss.aspx?topicid=2");
       req1.Method = "GET";
 req1.Proxy = System.Net.GlobalProxySelection.GetEmptyWebProxy();  
       result1=  req1.BeginGetResponse(cb,req1); 
        return result1;
    }

    IAsyncResult BeginAsyncWork2(Object sender, EventArgs e, AsyncCallback cb, object state)
    {
        AddTraceMessage("BeginGetRSSTwo");
        this.req2 = (HttpWebRequest)WebRequest.Create("http://www.eggheadcafe.com/forumrss.aspx?topicid=4");
        req2.Method = "GET";
        req2.Proxy = System.Net.GlobalProxySelection.GetEmptyWebProxy();
        result2 = req2.BeginGetResponse(cb, req2);
        return result2;
    }
    
    void EndAsyncWork1(IAsyncResult asyncResult)
    {      
        AddTraceMessage("EndAsyncWork1");       
      if (result1!=null)
        {
            AddTraceMessage("EndGetRssOne");        
            WebResponse response = (WebResponse)req1.EndGetResponse(asyncResult);
            Stream streamResponse = response.GetResponseStream();
             ds1 = new DataSet();
            ds1.ReadXml(streamResponse);
            streamResponse.Close();
        }
     
    }
    void EndAsyncWork2(IAsyncResult asyncResult)
    {
        AddTraceMessage("EndAsyncWork2");  
        if (result2 != null)
        {
            AddTraceMessage("EndGetRssTwo");
            WebResponse response2 = (WebResponse)req2.EndGetResponse(asyncResult);
            Stream streamResponse2 = response2.GetResponseStream();
            ds2 = new DataSet();
            ds2.ReadXml(streamResponse2);
            streamResponse2.Close();
        }
    }

    void TimeoutHandler(IAsyncResult asyncResult)
    {
        AddTraceMessage("Request Timed Out");
        Response.Write("<strong>async Request timed out</strong><br />");
    }

    private void MessageOut()
    {
        Page.Trace.Write(_trace.ToString());
        if (ds1.Tables.Count > 0)
            this.Label1.Text += "Got " + ds1.Tables[2].Rows.Count.ToString() + " Rows from response1  <br>";

        if (ds2.Tables.Count > 0)
            this.Label1.Text += "Got " + ds2.Tables[2].Rows.Count.ToString() + " Rows from response2  <br>";
    }

    StringBuilder _trace = new StringBuilder();
    DateTime _pageStartTime = DateTime.Now;
    public void AddTraceMessage(string message)
    {
        double t = (DateTime.Now - _pageStartTime).TotalSeconds;
        lock (_trace)
        {
            _trace.AppendFormat("Thread:[{0:000}] {1:00.000} -- {2}\r\n",
                System.Threading.Thread.CurrentThread.GetHashCode(), t, message);
        }
    }
}